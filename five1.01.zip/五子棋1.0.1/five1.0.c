#include <SDL.h>
#include <SDL_image.h>  // For loading image files
#include <SDL_ttf.h>    // For text rendering
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <windows.h>
#define OFFSIZE 20           // ������������ʼ 
#define SIZE 15          // ���������̴�С
#define CELL_SIZE 40      // ÿ�����ӵ����ش�С
#define WINDOW_WIDTH (SIZE * CELL_SIZE)
#define WINDOW_HEIGHT (SIZE * CELL_SIZE)

#define EMPTY '.'
#define PLAYER1 'X'
#define PLAYER2 'O'
int getStepCount();
int getX(int iX);
int getY(int iY); 
void initAlgorithm();
int exeAlgorithm(int row ,int col,char alphaFlag);
typedef enum { PVP, PVE, REPLAY } GameMode;
char *localeToUTF8(char *src){
   static char *buf = NULL;
   if(buf){
       free(buf);
       buf = NULL;
   }
   wchar_t *unicode_buf;
   int nRetLen = MultiByteToWideChar(CP_ACP,0,src,-1,NULL,0);
   unicode_buf = (wchar_t*)malloc((nRetLen+1)*sizeof(wchar_t));
   MultiByteToWideChar(CP_ACP,0,src,-1,unicode_buf,nRetLen);
   nRetLen = WideCharToMultiByte(CP_UTF8,0,unicode_buf,-1,NULL,0,NULL,NULL);
   buf = (char*)malloc(nRetLen+1);
   WideCharToMultiByte(CP_UTF8,0,unicode_buf,-1,buf,nRetLen,NULL,NULL);
   free(unicode_buf);
   return buf;
}
char* localeToUTF8_2(char* src)
{
    char* buf = NULL;
    int nRetLen = 0;
    
    wchar_t* unicode_buf = NULL;
    // *function: MultiByteToWideChar (Maps a character string to a UTF-16 (wide character) string.)
    // - UINT CodePage (Code page to use in performing the conversion. )
    //                CP_ACP: The system default Windows ANSI code page.
    // - DWORD dwFlags (Flags indicating the conversion type)
    //                0:
    // - LPCSTR lpMultiByteStr (Pointer to the character string to convert.)
    //                src: the word that you want to conver
    // - int cbMultiByte (you want to process size of lpMultiByteStr)
    //                -1:  the function processes the entire input string, including the terminating null character. when the input string
    //                            not contains terminating null character, it will failure.
    // - LPWSTR lpWideCharStr (Pointer to a buffer that receives the converted string.)
    //                NULL: no receives WideChar.
    // - int cchWideChar (size of lpWideCharStr)
    //                0: set the paramter for the function returns the required buffer size.
    // * return value : because of cchWideChar is 0, so returns the required buffer size of lpWideCharStr
    nRetLen = MultiByteToWideChar(CP_ACP, 0, src, -1, NULL, 0);
    //  allocate space for unicode_buf
    unicode_buf = (wchar_t*)malloc((nRetLen+1) * sizeof(wchar_t));
    // covert the src to utf-8, and store in unicode_buf
    MultiByteToWideChar(CP_ACP, 0, src, -1, unicode_buf, nRetLen);

    // *function: WideCharToMultiByte (Maps a UTF-16 (wide character) string to a new character string. )
    // - UINT CodePage (Code page to use in performing the conversion. )
    //                CP_UTF8: With this value set, lpDefaultChar and lpUsedDefaultChar must be set to NULL.
    // - DWORD dwFlags (Flags indicating the conversion type. )
    //                0 :
    // - LPCWSTR lpWideCharStr (Pointer to the Unicode string to convert.)
    //                unicode_buf : the word that you want to conver
    // - int cchWideChar (you want to process size of lpWideCharStr)
    //                -1: the function processes the entire input string, including the terminating null character. when the input string
    //                        not contains terminating null character, it will failure.
    // - LPSTR lpMultiByteStr (Pointer to a buffer that receives the converted string.)
    //                NULL : no receives MultiByteStr.
    // - int cbMultiByte (size of lpMultiByteStr)
    //                0: set the paramter for the function returns the required buffer size.
    // - LPCSTR lpDefaultChar (Pointer to the character to use if a character cannot be represented in the specified code page. )
    //                NULL : For the CP_UTF7 and CP_UTF8 settings for CodePage, this parameter must be set to NULL.
    // - LPBOOL lpUsedDefaultChar (Pointer to a flag that indicates if the function has used a default character in the conversion.)
    //                NULL : For the CP_UTF7 and CP_UTF8 settings for CodePage, this parameter must be set to NULL.
    nRetLen = WideCharToMultiByte(CP_UTF8, 0, unicode_buf, -1, NULL, 0, NULL, NULL);
    //  allocate space for buf
    buf = (char*)malloc(nRetLen+1);
    WideCharToMultiByte(CP_UTF8, 0, unicode_buf, -1, buf, nRetLen, NULL, NULL);

    // release space of unicode_buf
    free(unicode_buf);

    return buf;
}
void SDL_RenderFillCircle(SDL_Renderer* pRender, float x, float y, float r) {
    register float angle = 0;
    while (r > 0) {
        for (angle = 0; angle < 360; angle += 0.1) {
            SDL_RenderDrawPoint(pRender, x + r * SDL_cos(angle), y + r * SDL_sin(angle));
        }
        r -= 1;
    }
}

typedef struct {
    char board[SIZE][SIZE];
    int turn;  // 0: ���1, 1: ���2
    GameMode mode;  // ��Ϸģʽ
    int movesCount;
    int moves[SIZE * SIZE][2];  // �洢ÿһ���Ķ���
} GameState;

GameState game;
FILE *fileReplay;
// SDL ��ر���
SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;
SDL_Texture *bgTexture = NULL;  // Texture for the background image
TTF_Font *font = NULL;  // Font for rendering text

// ��ʼ������
void initBoard() {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            game.board[i][j] = EMPTY;
        }
    }
    game.turn = 0;  // ���1����
    game.movesCount = 0;  // ��ʼ���������
}

// ��������
void drawBoard() {
    // ���Ʊ���
    SDL_RenderCopy(renderer, bgTexture, NULL, NULL);

    // ��������
    SDL_SetRenderDrawColor(renderer, 0, 0, 45, 255);  // ��ɫ
    for (int i = 0; i < SIZE; i++) {
        SDL_RenderDrawLine(renderer, i * CELL_SIZE+OFFSIZE, 0+OFFSIZE, i * CELL_SIZE+OFFSIZE, SIZE * CELL_SIZE-OFFSIZE); // ����
        SDL_RenderDrawLine(renderer, 0+OFFSIZE, i * CELL_SIZE+OFFSIZE, SIZE * CELL_SIZE-OFFSIZE, i * CELL_SIZE+OFFSIZE); // ����
    }

    // ��������
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            if (game.board[i][j] == PLAYER1) {
                SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);  // ��ɫ (���1)
                SDL_RenderFillCircle(renderer, j * CELL_SIZE+OFFSIZE, i * CELL_SIZE+OFFSIZE, CELL_SIZE / 2 - 5);
            } else if (game.board[i][j] == PLAYER2) {
                SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);  // ��ɫ (���2)
                SDL_RenderFillCircle(renderer, j * CELL_SIZE+OFFSIZE , i * CELL_SIZE+OFFSIZE , CELL_SIZE / 2 - 5);
            }
        }
    }

    SDL_RenderPresent(renderer);
}

// ���ʤ������
int checkWin(int row, int col, char player) {
    int directions[4][2] = {{1, 0}, {0, 1}, {1, 1}, {1, -1}};  // �ĸ�����
    for (int d = 0; d < 4; d++) {
        int count = 1;  // ��ǰ������һ��
        for (int i = 1; i < 5; i++) {
            int newRow = row + i * directions[d][0];
            int newCol = col + i * directions[d][1];
            if (newRow >= 0 && newRow < SIZE && newCol >= 0 && newCol < SIZE && game.board[newRow][newCol] == player) {
                count++;
            } else {
                break;
            }
        }
        for (int i = 1; i < 5; i++) {
            int newRow = row - i * directions[d][0];
            int newCol = col - i * directions[d][1];
            if (newRow >= 0 && newRow < SIZE && newCol >= 0 && newCol < SIZE && game.board[newRow][newCol] == player) {
                count++;
            } else {
                break;
            }
        }
        if (count >= 5) {
            return 1;  // ʤ��
        }
    }
    return 0;
}

// ��¼ÿһ���Ķ��������浽�ļ�
void logMoveToFile(int row, int col, char player) {
    game.moves[game.movesCount][0] = row;
    game.moves[game.movesCount][1] = col;
    game.movesCount++;

    // ���ļ���׷��ģʽд��
    FILE *file = fopen("game_history.txt", "a");

    if (file) {
        fprintf(file, "Move %d: Player %c at (%d, %d)\n", game.movesCount, player, row, col);
        fclose(file);
    } else {
        printf("Failed to open file for logging!\n");
    }
    if (fileReplay) {
    	if(player==PLAYER1)
        	fprintf(fileReplay, "%d %d %d %d \n", game.movesCount, 1, row, col);
        else
        	fprintf(fileReplay, "%d %d %d %d \n", game.movesCount, 2, row, col);
    } else {
        printf("Failed to open fileReplay for logging!\n");
    }
}

// ��������¼�
int handleMouseClick(int x, int y) {
    int row = y / CELL_SIZE;
    int col = x / CELL_SIZE;
    int ret=0;
    // �ж��Ƿ��������ڲ��Ҹ�λ��Ϊ��
    if (row >= 0 && row < SIZE && col >= 0 && col < SIZE && game.board[row][col] == EMPTY) {
        char  currentPlayer= (game.turn % 2 == 0) ? PLAYER1 : PLAYER2;
        game.board[row][col] = currentPlayer;  // �������
        if (game.mode == PVE ) {
			exeAlgorithm(row ,col,currentPlayer);
        }

        // ��¼�������ļ�
        logMoveToFile(row, col, currentPlayer);

        // ���ʤ��
        if (checkWin(row, col, currentPlayer)) {
            printf("Player %c wins!\n", currentPlayer);
            //SDL_Delay(2000);  // �ȴ� 2 ����˳�
            //exit(0);  // �˳���Ϸ
            //MessageBox(0,"Hello World from boeplatformcore DLL!\n","Hi",MB_ICONINFORMATION);
            if(currentPlayer==PLAYER1)
            {
				ret=1;
			}
			else if(currentPlayer==PLAYER2)
			{
				ret=2;
			}
            
        }

        game.turn++;  // �л�����һ�����
    }
    return ret;
}

// ������Ե�����λ�ã��򵥵����ѡ��
void computerMove() {
    srand(time(NULL));
    int row, col;
    do {
        row = rand() % SIZE;
        col = rand() % SIZE;
    } while (game.board[row][col] != EMPTY);  // ȷ��ѡ����ǿ�λ

    game.board[row][col] = PLAYER2;
    printf("Computer placed at (%d, %d)\n", row, col);

    // ��¼���ԵĶ������ļ�
    logMoveToFile(row, col, PLAYER2);

    if (checkWin(row, col, PLAYER2)) {
        printf("Player O (Computer) wins!\n");
        SDL_Delay(2000);  // �ȴ� 2 ����˳�
        exit(0);  // �˳���Ϸ
    }

    game.turn++;  // �л�����һ�����
}
// ������Ե�����λ�ã��򵥵����ѡ��
int computerMoveNew( int row0, int col0) {
    int row=SIZE-row0;
	int col=col0;
	int ret=0;
    game.board[row][col] = PLAYER2;
    printf("Computer placed at (%d, %d)\n", row, col);

    // ��¼���ԵĶ������ļ�
    logMoveToFile(row, col, PLAYER2);

    if (checkWin(row, col, PLAYER2)) {
        printf("Player O (Computer) wins!\n");
        //SDL_Delay(2000);  // �ȴ� 2 ����˳�
        //exit(0);  // �˳���Ϸ
        ret=2;
    }

    game.turn++;  // �л�����һ�����
    return ret;
}

// SDL ��ʼ��
int initSDL() {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 0;
    }

    window = SDL_CreateWindow(localeToUTF8("Gomoku (������)"), SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
    if (!window) {
        printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
        return 0;
    }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        printf("Renderer could not be created! SDL_Error: %s\n", SDL_GetError());
        return 0;
    }

    // Initialize SDL_image
    if (!(IMG_Init(IMG_INIT_JPG) & IMG_INIT_JPG)) {
        printf("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
        return 0;
    }

    // Initialize SDL_ttf
    if (TTF_Init() == -1) {
        printf("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
        return 0;
    }

    return 1;
}

// �ر� SDL
void closeSDL() {
    TTF_CloseFont(font);  // Close the font
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    IMG_Quit();
    TTF_Quit();
}

// ���������ֲ���ʾ
void renderText(char *text_in, int x, int y, SDL_Color color) {
     char *text=localeToUTF8(text_in);
    //SDL_Surface *textSurface = TTF_RenderText_Solid(font, text, color);
	SDL_Surface *textSurface = TTF_RenderUTF8_Solid(font, text, color);
    if (!textSurface) {
        printf("Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError());
        return;
    }

    SDL_Texture *textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
    if (!textTexture) {
        printf("Unable to create texture from text surface! SDL_Error: %s\n", SDL_GetError());
        SDL_FreeSurface(textSurface);
        return;
    }

    SDL_Rect renderQuad = {x, y, textSurface->w, textSurface->h};
    SDL_RenderCopy(renderer, textTexture, NULL, &renderQuad);

    SDL_FreeSurface(textSurface);
    SDL_DestroyTexture(textTexture);
}

// ��ʾ�˵�
void showMenu() {
    // ���Ʊ���ͼ
    SDL_RenderCopy(renderer, bgTexture, NULL, NULL);

    // ���ư�ť
    SDL_Rect pvpButton = { (WINDOW_WIDTH / 4) - 75, WINDOW_HEIGHT / 2 - 25, 150, 50 };  // PVP Button
    SDL_Rect pveButton = { (WINDOW_WIDTH / 4) * 3 - 75, WINDOW_HEIGHT / 2 - 25, 150, 50 };  // PVE Button
    SDL_Rect replayButton = { (WINDOW_WIDTH / 2) - 75, WINDOW_HEIGHT / 2 + 50, 150, 50 };  // Replay Button

    SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);  // Yellow color
    SDL_RenderFillRect(renderer, &pvpButton);
    SDL_RenderFillRect(renderer, &pveButton);
    SDL_RenderFillRect(renderer, &replayButton);

    // Render text (PVP, PVE, Replay)
    SDL_Color textColor = {0, 0, 0, 255};  // Black color for the text
    renderText("PVP-�˶���", pvpButton.x + 50-40, pvpButton.y + 10, textColor);
    renderText("PVE-�˶Ի�", pveButton.x + 50-40, pveButton.y + 10, textColor);
    renderText("Replay-�ط�", replayButton.x + 20-15, replayButton.y + 10, textColor);

    SDL_RenderPresent(renderer);
}

// �����ط�
void playReplay() {
	
	printf("=======================playReplay start======================== \n");

	initBoard(); 
	drawBoard();
	
//    for (int i = 0; i < getStepCount(); i++) {
//        int row = SIZE-getX(i);
//        int col = getY(i);
//        char player = (i % 2 == 0) ? PLAYER1 : PLAYER2;
//        game.board[row][col] = player;  // ִ�лط�
//		//game.movesCount++;
//        drawBoard();
//        SDL_Delay(1000);  // ÿһ��֮���ӳ� 500 ����
//     }

    fileReplay = fopen("game_history_replay.txt", "r");
    
    if (fileReplay) {
    	
    	int movesCount;
    	int iplayer;
    	int row = 0;
        int col = 0;
        while(1)
        {
	        int items_read= fscanf(fileReplay, "%d%d%d%d", &movesCount, &iplayer, &row, &col);
			if (items_read == 4) 
			{
		        if(iplayer==1)    
		        	game.board[row][col] = PLAYER1;  // ִ�лط�
		        else
		        	game.board[row][col] = PLAYER2;  // ִ�лط�
		        drawBoard();
		        SDL_Delay(1000);  // ÿһ��֮���ӳ� 500 ����
		    }
			else if (items_read == EOF) 
			{
		        printf("End of file reached or error\n");
		        fclose(fileReplay);
		        break;
		    } 
			else 
			{
		        printf("Format mismatch\n");
		        fclose(fileReplay);
		        break;
		    } 
		}
        
    } else {
        printf("Failed to open file for logging!\n");
    }
     
	printf("=======================playReplay end======================== \n");
    // �طŽ���
    SDL_Delay(2000);  // �ȴ� 2 ����˳�
    //exit(0);  // �˳���Ϸ
    
}

// Main game loop
int main(int argc, char *argv[]) {		

    if (!initSDL()) {
        printf("Failed to initialize SDL!\n");
        return 1;
    }

    // Load background image (4.jpg)
    bgTexture = IMG_LoadTexture(renderer, "4.jpg");
    if (!bgTexture) {
        printf("Failed to load background image! SDL_image Error: %s\n", IMG_GetError());
        closeSDL();
        return 1;
    }

    // Load the font
   //font = TTF_OpenFont("arialbd.ttf", 24);  // Load font with a size of 24
    font = TTF_OpenFont("msyh.ttf", 24);  // Load font with a size of 24
    
    if (!font) {
        printf("Failed to load font! TTF_Error: %s\n", TTF_GetError());
        closeSDL();
        return 1;
    }

reStart:
	
	SDL_Event e;
	game.mode = PVP;  // Ĭ���� PVP ģʽ
    initBoard();  // ��ʼ������

    int quit = 0;
    int modeSelected = 0;

    // Show the menu
    while (!quit && !modeSelected) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = 1;
            } else if (e.type == SDL_MOUSEBUTTONDOWN) {
                if (e.button.button == SDL_BUTTON_LEFT) {
                    // ��ҵ����� -> PVP
                    if (e.button.x < WINDOW_WIDTH / 2) {
                        game.mode = PVP;
                    }
                    // ��ҵ���ұ� -> PVE
                    else if (e.button.x > (WINDOW_WIDTH / 2) + 75) {
                        game.mode = PVE;
                        initAlgorithm();  // ��ʼ���㷨 
                    }
                    // ��ҵ���м� -> Replay
                    else {
                        game.mode = REPLAY;
                    }
                    modeSelected = 1;
                    //goto reStart2;
                }
            }
        }
        showMenu();  // ��ʾ�˵�
        SDL_Delay(16);  // �ӳ�
    }
//reStart2:
    quit = 0;
    if (game.mode == REPLAY) {
    	printf("=============================================== \n");
        playReplay();  // �طŶԾ�
        goto reStart;
    }
    else
    {
    	fileReplay = fopen("game_history_replay.txt", "w");
	}

    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = 1;
            } else if (e.type == SDL_MOUSEBUTTONDOWN) {
                if (e.button.button == SDL_BUTTON_LEFT) {
                   int ret= handleMouseClick(e.button.x, e.button.y);
                   if(ret==1||ret==2)
                    {
                    	fclose(fileReplay);
	                    int response;
	                    if(ret==1)
	                    {
	                    	response = MessageBox(NULL, TEXT("PLAYER 1 ��ʤ���Ƿ��˳���Ϸ��"),TEXT("ѡ�����"), MB_YESNOCANCEL);
						}
						else
						{
							response = MessageBox(NULL, TEXT("PLAYER 2 ��ʤ���Ƿ��˳���Ϸ��"),TEXT("ѡ�����"), MB_YESNOCANCEL);
						}
	 
					    switch(response)
					    {
					        case IDYES:
					            // User selected "Yes"
					            exit(0);
					            break;
					        case IDNO:
					            // User selected "No"
					            goto reStart;
					            ret=1;
					            break;
					        case IDCANCEL:
					            // User selected "Cancel"					            
					            int response = MessageBox(NULL, TEXT("�Ƿ���?"), TEXT("ѡ�����"), MB_YESNO);
 
							    if(response == IDYES)
							    {
							        // User selected "Yes"
							        playReplay();
							        goto reStart;
							    }
							    else
							    {
							        // User selected "No"
							        exit(0);
							    }      
					            
					            ret=2;
					            break;
					    }	
					}

					//goto reStart;
                    if (game.mode == PVE && game.turn % 2 == 1) {
                        //computerMove();
                        //exeAlgorithm(0 ,0,'O');
                        //AI();
                        
						int ret= exeAlgorithm(0 ,0,'O');
						if(ret==1||ret==2)
						{
							fclose(fileReplay);
						    int response;
						    if(ret==1)
						    {
						    	response = MessageBox(NULL, TEXT("PLAYER 1 ��ʤ���Ƿ��˳���Ϸ��"),TEXT("ѡ�����"), MB_YESNOCANCEL);
							}
							else
							{
								response = MessageBox(NULL, TEXT("PLAYER 2 ��ʤ���Ƿ��˳���Ϸ��"),TEXT("ѡ�����"), MB_YESNOCANCEL);
							}						
						
						    switch(response)
						    {
						        case IDYES:
						            // User selected "Yes"
						            exit(0);
						            break;
						        case IDNO:
						            // User selected "No"
						            goto reStart;
						            ret=1;
						            break;
						        case IDCANCEL:
						            // User selected "Cancel"
							        int response = MessageBox(NULL, TEXT("�Ƿ���?"), TEXT("ѡ�����"), MB_YESNO);
	 
								    if(response == IDYES)
								    {
								        // User selected "Yes"
								        playReplay();
								        goto reStart;
								    }
								    else
								    {
								        // User selected "No"
								        exit(0);
								    }
						            ret=2;
						            break;
						    }	
						}
                        
                    }
                }
            }
        }

        drawBoard();  // �������̺�����
        SDL_Delay(16);  // �ӳ� 16 ���루60 FPS��
    }

    closeSDL();  // �˳� SDL
    return 0;
}

